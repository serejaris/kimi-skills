// ============================================================================
// Configuration File for Lipstick Product Website Template
// ============================================================================
// Edit this file to customize all content on your site.
// Do NOT modify component files - they read from this config.

// Navigation Configuration
export interface NavigationConfig {
  logo: string;
  links: Array<{ label: string; href: string }>;
}

export const navigationConfig: NavigationConfig = {
  logo: "",
  links: [],
};

// Hero Section Configuration
export interface HeroConfig {
  heroImage: string;
  titleText: string;
  subtitleLabel: string;
  ctaText: string;
}

export const heroConfig: HeroConfig = {
  heroImage: "",
  titleText: "",
  subtitleLabel: "",
  ctaText: "",
};

// Manifesto Section Configuration
// IMPORTANT: Each phrase is displayed in a small grid tile with limited space.
// English: strictly 1 word per tile (e.g. "BOLD", "FIERCE"). CJK/Asian languages: max 4 chars per tile (e.g. "自然之美").
// Do NOT put multiple words in one phrase — text will overflow and be invisible.
// Do NOT increase the tile font size in CSS — it is calibrated for the grid cell.
export interface ManifestoConfig {
  image: string;
  phrases: string[]; // EN: 1 word each, e.g. ["BOLD","FIERCE","FREE"] | CJK: max 4 chars, e.g. ["自然之美","自信绽放"]
}

export const manifestoConfig: ManifestoConfig = {
  image: "",
  phrases: [],
};

// Product Spotlight Section Configuration
// IMPORTANT: titlePhrases — same tile rules: EN 1 word per tile, CJK/Asian languages max 4 chars per tile.
export interface ProductSpotlightConfig {
  productImage: string;
  portraitImage: string;
  titlePhrases: string[]; // EN: 1 word each | CJK: max 4 chars each
  ctaText: string;
  price: string;
}

export const productSpotlightConfig: ProductSpotlightConfig = {
  productImage: "",
  portraitImage: "",
  titlePhrases: [],
  ctaText: "",
  price: "",
};

// Texture Section Configuration
// IMPORTANT: titlePhrases — same tile rules: EN 1 word per tile, CJK/Asian languages max 4 chars per tile.
export interface TextureConfig {
  portraitImage: string;
  macroImage: string;
  titlePhrases: string[]; // EN: 1 word each | CJK: max 4 chars each
  subtitle: string;
}

export const textureConfig: TextureConfig = {
  portraitImage: "",
  macroImage: "",
  titlePhrases: [],
  subtitle: "",
};

// Shade Range Section Configuration
export interface ShadeConfig {
  name: string;
  image: string;
}

export interface ShadeRangeConfig {
  heading: string[];
  headingAccent: string;
  shades: ShadeConfig[];
  price: string;
  ctaText: string;
}

export const shadeRangeConfig: ShadeRangeConfig = {
  heading: [],
  headingAccent: "",
  shades: [],
  price: "",
  ctaText: "",
};

// Final Statement Section Configuration
// IMPORTANT: phrases — same tile rules: EN 1 word per tile, CJK/Asian languages max 4 chars per tile.
export interface FinalStatementConfig {
  image1: string;
  image2: string;
  phrases: string[]; // EN: 1 word each | CJK: max 4 chars each
  subtitle: string;
}

export const finalStatementConfig: FinalStatementConfig = {
  image1: "",
  image2: "",
  phrases: [],
  subtitle: "",
};

// Contact Section Configuration
export interface ContactConfig {
  leftLinks: string[];
  formHeading: string[];
  formHeadingAccent: string;
  formDescription: string;
  emailPlaceholder: string;
  subscribeButtonText: string;
  socialLinks: Array<{ label: string; href: string }>;
  copyright: string;
  tagline: string;
}

export const contactConfig: ContactConfig = {
  leftLinks: [],
  formHeading: [],
  formHeadingAccent: "",
  formDescription: "",
  emailPlaceholder: "",
  subscribeButtonText: "",
  socialLinks: [],
  copyright: "",
  tagline: "",
};

// Site Metadata
export interface SiteConfig {
  title: string;
  description: string;
  language: string;
}

export const siteConfig: SiteConfig = {
  title: "",
  description: "",
  language: "",
};
